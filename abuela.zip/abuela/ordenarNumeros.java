package abuela;

import java.util.*;
import java.io.*;

/**
 * Programa ordenarNumeros
 * Lee un conjunto indeterminado de números desde la entrada estándar
 * y los muestra ordenados en la salida estándar.
 * 
 * Uso:
 *   java ordenarNumeros
 *   (después escribir números separados por espacios o saltos de línea y Ctrl+Z para terminar en Windows / Ctrl+D en Linux)
 */
public class ordenarNumeros {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> numeros = new ArrayList<>();

        // Leer hasta fin de entrada
        while (sc.hasNextInt()) {
            numeros.add(sc.nextInt());
        }
        sc.close();

        // Ordenar
        Collections.sort(numeros);

        // Imprimir
        for (int n : numeros) {
            System.out.print(n + " ");
        }
        System.out.println();
    }
}
