package abuela;

import java.util.*;
import java.io.*;

/**
 * Programa aleatorios
 * Genera al menos 40 números aleatorios entre 0 y 100
 * y los escribe en la salida estándar.
 *
 * Uso:
 *   java aleatorios
 */
public class aleatorios {
    public static void main(String[] args) {
        Random rnd = new Random();

        for (int i = 0; i < 40; i++) {
            int num = rnd.nextInt(101); // 0 a 100 inclusive
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
